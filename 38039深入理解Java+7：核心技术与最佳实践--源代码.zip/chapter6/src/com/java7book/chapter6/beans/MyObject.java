package com.java7book.chapter6.beans;

public class MyObject {
	public String greet(String name) {
		System.out.println("CALLED");
		return "alex";
	}
}
