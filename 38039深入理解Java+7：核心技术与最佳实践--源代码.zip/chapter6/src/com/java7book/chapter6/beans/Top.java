package com.java7book.chapter6.beans;

public class Top {
	public String getValue() {
		return "";
	}
	
	public void setValue() {
		
	}
}
