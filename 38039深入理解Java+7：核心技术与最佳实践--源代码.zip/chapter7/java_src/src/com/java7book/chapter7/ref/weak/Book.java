package com.java7book.chapter7.ref.weak;

public class Book {

}
