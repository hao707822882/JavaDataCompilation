package com.java7book.chapter7.ref;

public class StrongReferenceMain {

	public static void main(String[] args) {
		StrongReference sr = new StrongReference();
		sr.test();
	}

}
