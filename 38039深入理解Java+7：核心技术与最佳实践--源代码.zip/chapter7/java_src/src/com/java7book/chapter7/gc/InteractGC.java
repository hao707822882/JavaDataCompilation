package com.java7book.chapter7.gc;

public class InteractGC {

	public static void main(String[] args) {
		System.gc();
	}

}
