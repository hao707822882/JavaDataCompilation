package com.java7book.chapter9;

public class ClassForNameTest {
    static {
        System.out.println("初始化");
    }
}
