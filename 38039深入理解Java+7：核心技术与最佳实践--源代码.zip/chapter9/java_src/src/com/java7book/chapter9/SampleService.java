package com.java7book.chapter9;

public class SampleService implements Versionized {
    public String getVersion() {
        return "2.0";
    }
}
