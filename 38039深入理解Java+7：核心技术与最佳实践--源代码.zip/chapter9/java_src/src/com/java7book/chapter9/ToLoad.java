package com.java7book.chapter9;

public class ToLoad {

}
