package com.java7book.chapter9;

public class Sample {
    private Sample obj;
    
    public void setSample(Object obj) {
        this.obj = obj;
    }
}
