package com.java7book.securewebapp.service;


public class EmployeeServiceImpl implements EmployeeService {
	public Employee read(String employeeId) {
		return new Employee();
	}
}
