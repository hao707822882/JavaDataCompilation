package com.java7book.securewebapp.service;

public class Employee {

}
