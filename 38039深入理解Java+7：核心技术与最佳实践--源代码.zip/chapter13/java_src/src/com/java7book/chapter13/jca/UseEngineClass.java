package com.java7book.chapter13.jca;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class UseEngineClass {
    public static void main(String[] args) throws NoSuchAlgorithmException {
        MessageDigest md = MessageDigest.getInstance("MD5");
        
    }
}
