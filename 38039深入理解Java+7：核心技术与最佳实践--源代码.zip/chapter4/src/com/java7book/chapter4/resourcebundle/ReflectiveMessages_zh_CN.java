/*
 * Copyright 2011 Cheng Fu
 */
package com.java7book.chapter4.resourcebundle;

/**
 *
 * @author chengfu
 */
public class ReflectiveMessages_zh_CN {
    public static String greet() {
        return "你好，" + (Math.random() > 0.5 ? "先生" : "女士");
    }
}
