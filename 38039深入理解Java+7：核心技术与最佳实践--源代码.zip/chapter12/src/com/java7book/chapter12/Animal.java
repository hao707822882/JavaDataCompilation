package com.java7book.chapter12;

public class Animal {
    
}
