package com.java7book.chapter12;

import java.util.List;

public class StaticGeneric <T> { 
    public static void method() {
        
    }
}
