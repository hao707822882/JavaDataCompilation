package com.java7book.chapter12;

import java.io.Serializable;

public class CloneableSerializable<T extends Cloneable & Serializable> {
    public void serialize(T obj) {
        
    }
}
