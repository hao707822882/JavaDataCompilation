package com.java7book.chapter12;

class OverloadParent {
    public void method() {
        
    }
}

public class Overload extends OverloadParent {
    public void method() {
        
    }
}
