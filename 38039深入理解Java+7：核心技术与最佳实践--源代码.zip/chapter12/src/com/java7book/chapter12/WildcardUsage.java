package com.java7book.chapter12;

import java.util.List;

public class WildcardUsage {
    public void useList(List<?> list) {
        
    }
}
