package com.java7book.chapter1.stringinswitch;

public class TitleDuplicate {
    public String generate(String name, String gender) {
        String title = "";
        switch (gender) {
            case "男" :
                break;
            /*
                case "\u7537":
                break;
             */
        }
        return title;
    }
}
