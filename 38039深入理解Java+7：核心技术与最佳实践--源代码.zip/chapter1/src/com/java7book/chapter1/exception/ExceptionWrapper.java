package com.java7book.chapter1.exception;

public class ExceptionWrapper {
    
}
