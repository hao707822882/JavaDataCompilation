package com.java7book.chapter1.numericliteral;

public class NumericLiteralMain {

    public static void main(String[] args) {
       BinaryIntegralLiteral numericLiteral = new BinaryIntegralLiteral();
       numericLiteral.display();
       Underscore underscore = new Underscore();
       underscore.display();
    }
}
