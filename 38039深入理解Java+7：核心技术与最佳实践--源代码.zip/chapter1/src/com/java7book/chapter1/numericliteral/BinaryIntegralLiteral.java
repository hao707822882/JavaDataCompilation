package com.java7book.chapter1.numericliteral;
import static java.lang.System.out;
public class BinaryIntegralLiteral {
    public void display() {
        out.println(0b001001); //输出9
        out.println(0B001110); //输出14
    }
}
