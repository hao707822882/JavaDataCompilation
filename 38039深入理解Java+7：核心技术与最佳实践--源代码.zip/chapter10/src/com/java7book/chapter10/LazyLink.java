package com.java7book.chapter10;

public class LazyLink {
    public static void main(String[] args) {
        ToBeLinked toBeLinked = null;
        System.out.println("使用延迟链接。");
    }
}
