package com.java7book.chapter10;

public class ToBeLinked {

}
