package com.java7book.chapter11.thread;

public class BasicThread {

    private static class Work implements Runnable {
        public void run() {
            
        }
    }
}
