package com.java7book.chapter11.thread;

public class Queue<T> {
    public T take() {
        return null;
    }
}
