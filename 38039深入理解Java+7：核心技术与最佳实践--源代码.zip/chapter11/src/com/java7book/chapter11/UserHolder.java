package com.java7book.chapter11;

public class UserHolder {
    public static WrongUser user = null;
}
