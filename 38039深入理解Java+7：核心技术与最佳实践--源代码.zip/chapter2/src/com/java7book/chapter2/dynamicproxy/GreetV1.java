/*
 * Copyright 2011 Cheng Fu
 */
package com.java7book.chapter2.dynamicproxy;

/**
 *
 * @author chengfu
 */
public interface GreetV1 {
    String greet(String name, String gender) throws GreetException;
}
