/*
 * Copyright 2011 Cheng Fu
 */
package com.java7book.chapter2.reflect;

/**
 *
 * @author chengfu
 */
public class FieldContainer {
    public static int count = 1;
    public String name = "Alex";
    private String value = "";
}
