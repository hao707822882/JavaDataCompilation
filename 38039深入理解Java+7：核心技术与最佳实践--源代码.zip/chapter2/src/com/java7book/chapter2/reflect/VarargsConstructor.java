package com.java7book.chapter2.reflect;

public class VarargsConstructor {
	public VarargsConstructor(String address, String... names) {
	}
}
