/*
 * Copyright 2011 Cheng Fu
 */
package com.java7book.chapter2.reflect;

/**
 *
 * @author chengfu
 */
public class MethodContainer {
    private void privateMethod() {
        
    }
    public void publicMethod() {
        
    }
}
