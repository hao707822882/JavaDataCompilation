/*
 * Copyright 2011 Cheng Fu
 */
package com.java7book.chapter2.invoke.lookup;

/**
 *
 * @author chengfu
 */
public class MethodHandleLookupParent {
    protected void protectedMethod() {
        System.out.println("PROTECTED");
    }
}
