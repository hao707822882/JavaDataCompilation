/*
 * Copyright 2011 Cheng Fu
 */
package com.java7book.chapter2.invoke.lookup;

/**
 *
 * @author chengfu
 */
public class Sample {
    public String name;
    public static int value;
}
