/*
 * Copyright 2011 Cheng Fu
 */
package com.java7book.chapter2.invoke.interceptors;

/**
 *
 * @author chengfu
 */
public class SimpleClassMain {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        SimpleClass sc = new SimpleClass();
        sc.method2("abc"); 
    }
}
