/*
 * Copyright 2011 Cheng Fu
 */
package com.java7book.chapter2.invoke;

/**
 *
 * @author chengfu
 */
public interface SampleInterface {
    void sampleMethodInInterface();
}
