/*
 * Copyright 2011 Cheng Fu
 */
package com.java7book.chapter2.invoke;

/**
 *
 * @author chengfu
 */
public class Sample implements SampleInterface {

    @Override
    public void sampleMethodInInterface() {}
    
    public void normalMethod() {}
    
    public static void staticSampleMethod() {}
    
}
