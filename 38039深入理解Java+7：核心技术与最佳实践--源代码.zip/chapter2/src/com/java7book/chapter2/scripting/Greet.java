/*
 * Copyright 2011 Cheng Fu
 */
package com.java7book.chapter2.scripting;

/**
 *
 * @author chengfu
 */
public interface Greet {
    String getGreeting(String name);
}
