
public class CalculatorMain {
	public static double calculate() {
	    return (3+2)*5;
	}
}
