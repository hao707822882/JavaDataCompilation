package com.java7book.chapter8.asm;

public class CreatedObjectMain {
    public static void main(String[] args) {
        new CreatedObject();
        new CreatedObject();
        new CreatedObject();
        new CreatedObject();
    }
}
