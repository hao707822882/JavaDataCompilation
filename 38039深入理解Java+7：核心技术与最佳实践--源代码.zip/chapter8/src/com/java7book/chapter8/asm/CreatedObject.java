package com.java7book.chapter8.asm;

public class CreatedObject {
    public CreatedObject() {
        System.out.println("CREATED"); 
    }
}
