package com.java7book.chapter8.compiler;

public class CompileException extends Exception {

	public CompileException() {
		super();
	}

	public CompileException(String arg0, Throwable arg1) {
		super(arg0, arg1);
	}

	public CompileException(String arg0) {
		super(arg0);
	}

	public CompileException(Throwable arg0) {
		super(arg0);
	}

}
