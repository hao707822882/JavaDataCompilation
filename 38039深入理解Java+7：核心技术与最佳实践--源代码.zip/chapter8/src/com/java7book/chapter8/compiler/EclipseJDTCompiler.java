package com.java7book.chapter8.compiler;

public class EclipseJDTCompiler {

}
