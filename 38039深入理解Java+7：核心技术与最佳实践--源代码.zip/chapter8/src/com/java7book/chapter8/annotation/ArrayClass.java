package com.java7book.chapter8.annotation;

@WithArrayValue(name = "Test", appliedTo = {String.class, Integer.class})
public class ArrayClass {
}
