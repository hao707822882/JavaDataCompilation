package com.java7book.chapter8.annotation;

@Author(name = "Alex", email = "alex@example.org")
public class MyClass1 {

}
