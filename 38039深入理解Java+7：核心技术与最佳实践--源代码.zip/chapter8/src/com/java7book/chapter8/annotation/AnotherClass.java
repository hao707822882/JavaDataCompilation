package com.java7book.chapter8.annotation;

import com.java7book.chapter8.annotation.Employee.EMPLOYEE_TYPE;

@Employee(EMPLOYEE_TYPE.REGULAR)
public class AnotherClass {

}
