package com.java7book.chapter8.annotation;

public class MySubClass extends MyClass1 {

}
