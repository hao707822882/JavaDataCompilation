package com.java7book.chapter8.annotation;

public interface Greeting {
    String greet();
}
