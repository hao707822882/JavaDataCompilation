package com.java7book.chapter8.annotation;

public class User {
    public boolean equals(User user) {
        return true;
    }
}
