package com.java7book.chapter8.annotation;

public @interface SupportedGreetingLocales {
    String[] value();
}
