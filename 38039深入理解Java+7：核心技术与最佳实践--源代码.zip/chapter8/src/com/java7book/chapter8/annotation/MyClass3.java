package com.java7book.chapter8.annotation;

@Author(name = "Bob", email = "bob@example.org")
public class MyClass3 {

}
