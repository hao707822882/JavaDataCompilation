package com.java7book.chapter8.annotation;

public class DefaultEmployeeInfoManager implements EmployeeInfoManager {

    public void updateSalary() {
        
    }

}
