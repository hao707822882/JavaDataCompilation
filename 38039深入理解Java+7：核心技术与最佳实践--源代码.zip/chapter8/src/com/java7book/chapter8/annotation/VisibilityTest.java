package com.java7book.chapter8.annotation;

@Visible
public class VisibilityTest {
    private String name;
    
    public int count;
}
