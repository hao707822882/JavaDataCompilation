package com.java7book.chapter8.annotation.i18n;

public class DemoClassMain {
    public static void main(String[] args) {
        DemoClass demoClass = new DemoClass();
        demoClass.output();
    }
}
