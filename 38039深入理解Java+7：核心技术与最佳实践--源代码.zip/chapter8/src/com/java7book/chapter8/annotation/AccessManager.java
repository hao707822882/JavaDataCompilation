package com.java7book.chapter8.annotation;

public class AccessManager {
    public static String getCurrentUserRole() {
        return "staff";
    }
}
